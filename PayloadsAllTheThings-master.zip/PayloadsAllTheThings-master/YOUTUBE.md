# Youtube

## Channels

- [IppSec Channel - Hack The Box Writeups](https://www.youtube.com/channel/UCa6eh7gCkpPo5XXUDfygQQA)
- [LiveOverflow - Explore weird machines...](https://www.youtube.com/channel/UClcE-kVhqyiHCcjYwcpfj9w)
- [GynvaelEN - Podcasts about CTFs, computer security, programing and similar things.](https://www.youtube.com/channel/UCCkVMojdBWS-JtH7TliWkVg)
- [John Hammond - Wargames and CTF writeups](https://www.youtube.com/channel/UCVeW9qkBjo3zosnqUbG7CFw)
- [Murmus CTF - Weekly live streamings](https://www.youtube.com/channel/UCUB9vOGEUpw7IKJRoR4PK-A)
- [PwnFunction](https://www.youtube.com/channel/UCW6MNdOsqv2E9AjQkv9we7A)
- [OJ Reeves](https://www.youtube.com/channel/UCz2aqRQWMhJ4wcJq3XneqRg)
- [Hacksplained - A Beginner Friendly Guide to Hacking](https://www.youtube.com/c/hacksplained)
- [STÖK](https://www.youtube.com/c/STOKfredrik)
- [Defcon](https://www.youtube.com/user/DEFCONConference)
- [Hackersploit](https://www.youtube.com/channel/UC0ZTPkdxlAKf-V33tqXwi3Q)
- [The Cyber Mentor](https://www.youtube.com/channel/UC0ArlFuFYMpEewyRBzdLHiw)
- [Nahamsec](https://www.youtube.com/c/Nahamsec)
- [Hackerone](https://www.youtube.com/channel/UCsgzmECky2Q9lQMWzDwMhYw)
- [The Hated one](https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q)
- [stacksmashing / Ghidra Ninja](https://www.youtube.com/channel/UC3S8vxwRfqLBdIhgRlDRVzw)
- [Hak5](https://www.youtube.com/channel/UC3s0BtrBJpwNDaflRSoiieQ)

## Conferences

- [Hunting for Top Bounties - Nicolas Grégoire](https://www.youtube.com/watch?v=mQjTgDuLsp4)
- [BSidesSF 101 The Tales of a Bug Bounty Hunter - Arne Swinnen](https://www.youtube.com/watch?v=dsekKYNLBbc)
- [Security Fest 2016 The Secret life of a Bug Bounty Hunter - Frans Rosén](https://www.youtube.com/watch?v=KDo68Laayh8)
- [The Conscience of a Hacker](https://www.youtube.com/watch?v=0tEnnvZbYek)
- [Defcon 2020 Talks](https://www.youtube.com/user/DEFCONConference/videos)
